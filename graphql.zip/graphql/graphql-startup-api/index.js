const { ApolloServer, gql } = require('apollo-server');

// Hardcoded array of startups
const startups = [
  { id: '1', name: 'Startup One', industry: 'Tech', founder: 'Alice' },
  { id: '2', name: 'Startup Two', industry: 'Health', founder: 'Bob' },
  { id: '3', name: 'Startup Three', industry: 'Finance', founder: 'Charlie' },
];

// Define the GraphQL schema
const typeDefs = gql`
  type Startup {
    id: ID!
    name: String!
    industry: String!
    founder: String!
  }

  type Query {
    startups: [Startup]
    startup(id: ID!): Startup
  }
`;

// Define the resolvers
const resolvers = {
  Query: {
    startups: () => startups,
    startup: (parent, args) => startups.find(startup => startup.id === args.id),
  },
};

// Create an ApolloServer instance
const server = new ApolloServer({ typeDefs, resolvers });

// Start the server
server.listen().then(({ url }) => {
  console.log(`🚀  Server ready at ${url}`);
});
